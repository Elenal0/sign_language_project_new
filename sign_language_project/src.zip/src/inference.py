import sys
import numpy as np
import joblib
from pathlib import Path

from src.config          import PROCESSED_DATA_DIR, MODELS_DIR
from src.preprocessing   import load_video_frames
from src.feature_extraction import HandLandmarkExtractor


def load_model():
    model_path   = MODELS_DIR         / "sign_language_model.pkl"
    encoder_path = PROCESSED_DATA_DIR / "label_encoder.pkl"

    if not model_path.exists():
        raise FileNotFoundError("Model not found. Run `python -m src.train` first.")
    if not encoder_path.exists():
        raise FileNotFoundError("Label encoder not found. Run `python -m src.build_dataset` first.")

    model         = joblib.load(model_path)
    label_encoder = joblib.load(encoder_path)
    return model, label_encoder


def predict_video(video_path: Path):
    print("Loading model …")
    model, label_encoder = load_model()

    print("Extracting features …")
    extractor = HandLandmarkExtractor()
    frames    = load_video_frames(video_path)
    features  = extractor.extract_from_frames(frames)

    if features is None:
        print("ERROR: No hands detected in the video.")
        return

    features         = features.reshape(1, -1)
    predicted_label  = model.predict(features)[0]   
    probabilities    = model.predict_proba(features)[0]

    model_class_labels = model.classes_

    print("\n── Prediction Result ──────────────────────────")
    print(f"  Predicted Sign : {predicted_label}")
    print("\n  All Scores:")
    for label, prob in zip(model_class_labels, probabilities):
        bar = "█" * int(prob * 20)
        print(f"    {label:12s} {prob:.4f}  {bar}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python -m src.inference <path_to_video>")
        sys.exit(1)
    video_path = Path(sys.argv[1])
    if not video_path.exists():
        print("Video file not found.")
        sys.exit(1)
    predict_video(video_path)