from transformers import T5ForConditionalGeneration, T5Tokenizer

class SentenceGenerator:
    """Generate grammatically correct sentences from sign-language gloss."""

    PROMPTS = [
        "grammar: {}",
        "fix grammar: {}",
        "paraphrase: {}",
    ]

    def __init__(self, model_name: str = "t5-small"):
        print("NLP  Loading T5 model, please wait …")
        self.tokenizer = T5Tokenizer.from_pretrained(model_name)
        self.model     = T5ForConditionalGeneration.from_pretrained(model_name)
        self.model.eval()
        print("NLP  T5 model loaded successfully.")

    def _generate_from_prompt(self, prompt: str, num_seqs: int = 6) -> list:
        """Run beam-search on a single prompt; return decoded strings."""
        inputs = self.tokenizer(
            prompt,
            return_tensors="pt",
            max_length=128,
            truncation=True,
        )
        outputs = self.model.generate(
            inputs["input_ids"],
            max_length=64,
            num_beams=num_seqs,
            num_return_sequences=num_seqs,
            early_stopping=True,
            no_repeat_ngram_size=2,
            length_penalty=1.0,
        )
        return [
            self.tokenizer.decode(o, skip_special_tokens=True).strip().capitalize()
            for o in outputs
        ]

    def generate(self, gloss_text: str, num_options: int = 3) -> list:
        seen    = set()
        results = []

        for prompt_template in self.PROMPTS:
            if len(results) >= num_options:
                break
            prompt    = prompt_template.format(gloss_text.strip())
            sentences = self._generate_from_prompt(prompt, num_seqs=6)

            for sentence in sentences:
                if len(results) >= num_options:
                    break
                if sentence and len(sentence) > 3 and sentence not in seen:
                    seen.add(sentence)
                    results.append(sentence)

        fallbacks = [
            gloss_text.strip().capitalize() + ".",
            gloss_text.strip().capitalize(),
            gloss_text.strip(),
        ]
        for fb in fallbacks:
            if len(results) >= num_options:
                break
            if fb and fb not in seen:
                seen.add(fb)
                results.append(fb)

        return results[:num_options]