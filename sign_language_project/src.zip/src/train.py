import numpy as np                          
import joblib

from sklearn.model_selection import train_test_split
from sklearn.ensemble       import RandomForestClassifier
from sklearn.decomposition  import PCA
from sklearn.metrics        import classification_report, accuracy_score
from sklearn.pipeline       import Pipeline
from sklearn.preprocessing  import LabelEncoder

from src.config import PROCESSED_DATA_DIR, MODELS_DIR, TEST_SIZE, RANDOM_STATE


def load_dataset():
    X = np.load(PROCESSED_DATA_DIR / "X.npy")
    y = np.load(PROCESSED_DATA_DIR / "y.npy")
    return X, y


def train_model():
    print("Loading dataset...")
    X, y = load_dataset()
    print(f"  Total samples  : {len(X)}")
    print(f"  Feature shape  : {X.shape}")
    print(f"  Classes        : {sorted(set(y))}")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=TEST_SIZE,
        random_state=RANDOM_STATE,
        stratify=y,           # equal class split
    )
    print(f"  Training samples : {len(X_train)}")
    print(f"  Testing  samples : {len(X_test)}")

    # ── PCA: use at most 50 components ───────────────────────────────────────
    max_pca      = min(len(X_train) - 1, X_train.shape[1])
    n_components = min(50, max_pca)
    print(f"  PCA components   : {n_components}")

    pipeline = Pipeline([
        ("pca", PCA(n_components=n_components)),
        ("rf",  RandomForestClassifier(
            n_estimators=500,        # more trees → better accuracy
            max_depth=None,
            min_samples_split=2,
            class_weight="balanced", # handles class imbalance
            random_state=RANDOM_STATE,
            n_jobs=-1,               # use all CPU cores
        )),
    ])

    print("\nTraining RandomForest model …")
    pipeline.fit(X_train, y_train)

    print("Evaluating model …")
    y_pred   = pipeline.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)

    print("=" * 55)
    print(f"  Accuracy : {accuracy:.4f}  ({accuracy * 100:.1f}%)")
    print("=" * 55)
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))

    # ── Save ─────────────────────────────────────────────────────────────────
    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    model_path = MODELS_DIR / "sign_language_model.pkl"
    joblib.dump(pipeline, model_path)
    print(f"Model saved → {model_path}")


if __name__ == "__main__":
    train_model()