import cv2
import numpy as np
import mediapipe as mp

class HandLandmarkExtractor:
    """Extracts hand landmarks using MediaPipe."""

    def __init__(self, max_hands=2, min_detection_confidence=0.7,
                 min_tracking_confidence=0.5):
        
        # Check if mediapipe loaded correctly (HPC headless check)
        if not hasattr(mp, 'solutions'):
            raise RuntimeError(
                "MediaPipe 'solutions' module is missing. Your installation is broken on this HPC "
                "environment due to missing system libraries. Try running: "
                "pip uninstall opencv-python mediapipe && pip install opencv-python-headless mediapipe"
            )
            
        self.mp_hands = mp.solutions.hands
        self.mp_draw  = mp.solutions.drawing_utils

        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=max_hands,
            min_detection_confidence=min_detection_confidence,
            min_tracking_confidence=min_tracking_confidence,
        )

    def extract_landmarks(self, frame):
        """Extract raw hand landmarks from a single BGR frame."""
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results   = self.hands.process(frame_rgb)
        landmarks = np.zeros(126, dtype=np.float32)

        if results.multi_hand_landmarks:
            for hand_idx, hand_lms in enumerate(results.multi_hand_landmarks[:2]):
                offset = hand_idx * 63  # 21 landmarks × 3 coords per hand
                for lm_idx, lm in enumerate(hand_lms.landmark):
                    landmarks[offset + lm_idx * 3]     = lm.x
                    landmarks[offset + lm_idx * 3 + 1] = lm.y
                    landmarks[offset + lm_idx * 3 + 2] = lm.z
                self.mp_draw.draw_landmarks(
                    frame, hand_lms, self.mp_hands.HAND_CONNECTIONS
                )

        hand_detected = results.multi_hand_landmarks is not None
        return landmarks, frame, hand_detected

    def normalize_landmarks(self, landmarks: np.ndarray) -> np.ndarray:
        """Wrist-relative normalisation (scale + translation invariant)."""
        reshaped = landmarks.reshape(2, 21, 3)   
        for h in range(2):
            wrist = reshaped[h, 0].copy()
            reshaped[h] = reshaped[h] - wrist
            norms    = np.linalg.norm(reshaped[h], axis=1)
            max_dist = np.max(norms)
            if max_dist > 0:
                reshaped[h] = reshaped[h] / max_dist
        return reshaped.flatten()

    def extract_from_frames(self, frames) -> np.ndarray:
        """Extract a fixed-size (252,) feature vector from a list of frames."""
        all_features = []
        for frame in frames:
            landmarks, _, detected = self.extract_landmarks(frame)
            if detected:
                raw        = landmarks.copy()
                normalised = self.normalize_landmarks(landmarks)
                all_features.append(np.concatenate([raw, normalised]))

        if not all_features:
            return None
        return np.mean(all_features, axis=0)   

    def count_extended_fingers(self, frame) -> int:
        """Count extended fingers (0-5) for option selection."""
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results   = self.hands.process(frame_rgb)
        if not results.multi_hand_landmarks:
            return 0

        lm = results.multi_hand_landmarks[0].landmark
        finger_tips = [8, 12, 16, 20]
        finger_pips = [6, 10, 14, 18]
        count = sum(1 for tip, pip in zip(finger_tips, finger_pips)
                    if lm[tip].y < lm[pip].y)

        if abs(lm[4].x - lm[0].x) > abs(lm[3].x - lm[0].x):
            count += 1

        return count

    def __del__(self):
        if hasattr(self, "hands"):
            self.hands.close()