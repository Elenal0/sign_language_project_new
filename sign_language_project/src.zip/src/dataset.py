from tqdm import tqdm
import numpy as np
import joblib
from pathlib import Path

from src.config import (RAW_DATA_DIR, PROCESSED_DATA_DIR, CLASSES,
                        MODELS_DIR)
from src.preprocessing import load_video_frames
from src.feature_extraction import HandLandmarkExtractor
from sklearn.preprocessing import LabelEncoder


class DatasetBuilder:
    """Builds X.npy / y.npy / label_encoder.pkl from raw video files."""

    VIDEO_EXTENSIONS = ("*.AVI", "*.avi", "*.mp4", "*.MP4", "*.mov", "*.MOV")

    def __init__(self):
        self.extractor     = HandLandmarkExtractor()
        self.label_encoder = LabelEncoder()

    def _find_videos(self, class_name: str) -> list:
        class_dir = RAW_DATA_DIR / class_name

        if not class_dir.exists():
            raise FileNotFoundError(
                f"Class folder not found: {class_dir}\n"
            )

        nested_dir = class_dir / f"{class_name}Raw"
        if nested_dir.exists():
            videos = []
            for ext in self.VIDEO_EXTENSIONS:
                videos.extend(nested_dir.glob(ext))
            if videos:
                return sorted(videos)

        videos = []
        for ext in self.VIDEO_EXTENSIONS:
            videos.extend(class_dir.glob(ext))
        return sorted(videos)

    def build(self):
        print("\n=== Starting dataset build ===")

        if not RAW_DATA_DIR.exists():
            raise FileNotFoundError(
                f"Raw data directory not found: {RAW_DATA_DIR}"
            )

        PROCESSED_DATA_DIR.mkdir(parents=True, exist_ok=True)
        MODELS_DIR.mkdir(parents=True, exist_ok=True)

        X, y          = [], []
        total_skipped = 0

        for class_name in CLASSES:
            try:
                video_files = self._find_videos(class_name)
            except FileNotFoundError as e:
                print(f"  WARNING: {e}")
                continue

            if len(video_files) == 0:
                print(f"  WARNING: No video files found for class '{class_name}'")
                continue

            print(f"  {class_name:10s}: {len(video_files)} videos found")
            skipped = 0

            for video_path in tqdm(video_files, desc=f"  {class_name}", leave=False):
                try:
                    frames   = load_video_frames(video_path)
                    features = self.extractor.extract_from_frames(frames)
                    if features is None:
                        skipped += 1
                        continue
                    X.append(features)
                    y.append(class_name)
                except Exception as e:
                    skipped += 1

            if skipped:
                print(f"    ↳ skipped {skipped}/{len(video_files)} (no hand detected / corrupt)")
            total_skipped += skipped

        if len(X) == 0:
            raise RuntimeError(
                "No features extracted. Check that your video files contain "
                "visible hands and that MediaPipe is installed correctly."
            )

        X = np.array(X, dtype=np.float32)
        y = np.array(y)

        self.label_encoder.fit(y)
        y_encoded = self.label_encoder.transform(y)

        np.save(PROCESSED_DATA_DIR / "X.npy", X)
        np.save(PROCESSED_DATA_DIR / "y.npy", y)
        joblib.dump(self.label_encoder, PROCESSED_DATA_DIR / "label_encoder.pkl")

        print("\n=== Build complete ===")
        print(f"  Feature matrix shape : {X.shape}")
        print(f"  Total valid samples  : {len(X)}")
        print(f"  Total skipped        : {total_skipped}")
        print(f"  Classes              : {list(self.label_encoder.classes_)}")
        print(f"  Saved X.npy, y.npy, label_encoder.pkl → {PROCESSED_DATA_DIR}")