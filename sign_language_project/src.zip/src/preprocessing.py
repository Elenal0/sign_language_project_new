import cv2
import numpy as np
from pathlib import Path


def load_video_frames(video_path: Path):
    """Load all frames from a video file. Supports .AVI, .mp4, etc."""
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise ValueError(f"Could not open video: {video_path}")
    frames = []
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frames.append(frame)
    cap.release()
    if len(frames) == 0:
        raise ValueError(f"No frames extracted from {video_path}")
    return frames


def normalize_landmarks(landmarks: np.ndarray) -> np.ndarray:
    """Wrist-relative normalization for a (21, 3) or (N, 3) landmark array."""
    wrist     = landmarks[0].copy()
    landmarks = landmarks - wrist
    max_dist  = np.max(np.linalg.norm(landmarks, axis=1))
    if max_dist > 0:
        landmarks = landmarks / max_dist
    return landmarks